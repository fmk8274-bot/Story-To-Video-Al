/**
 * Main Application Coordinator - Story To Video AI
 */

const App = {
  activeScreenId: 'home-screen',
  selectedFormat: '9:16',
  selectedDuration: '1 Min',
  selectedQuality: '720p HD',

  init() {
    StorageManager.init();
    this.setupEventListeners();
    CreditsManager.updateUI();
    CharactersManager.renderUI();
    ProjectsManager.renderUI();
    this.updateResetTimer();
    setInterval(() => this.updateResetTimer(), 60000);

    setTimeout(() => {
      this.hideSplashScreen();
    }, 2000);
  },

  hideSplashScreen() {
    const splash = document.getElementById('splash-screen');
    if (splash && splash.classList.contains('active')) {
      splash.classList.remove('active');
      this.showScreen('home-screen');
    }
  },

  showScreen(screenId) {
    this.activeScreenId = screenId;

    document.querySelectorAll('.screen').forEach(s => s.classList.remove('active'));

    const target = document.getElementById(screenId);
    if (target) {
      target.classList.add('active');
      target.scrollTop = 0;
    }

    this.syncBottomNav(screenId);

    CreditsManager.updateUI();
    if (screenId === 'projects-screen') {
      ProjectsManager.renderUI();
    } else if (screenId === 'characters-screen') {
      CharactersManager.renderUI();
    } else if (screenId === 'credits-screen') {
      CreditsManager.renderHistoryList();
    }
  },

  syncBottomNav(screenId) {
    let navKey = 'home';
    if (screenId === 'home-screen') navKey = 'home';
    else if (screenId === 'create-screen' || screenId === 'scene-breakdown-screen') navKey = 'create';
    else if (screenId === 'projects-screen') navKey = 'projects';
    else if (screenId === 'credits-screen') navKey = 'credits';
    else if (screenId === 'settings-screen') navKey = 'settings';

    document.querySelectorAll('.nav-item').forEach(item => {
      item.classList.toggle('active', item.dataset.nav === navKey);
    });
  },

  showFullscreenView(viewId) {
    const view = document.getElementById(viewId);
    if (view) view.classList.add('active');
  },

  hideFullscreenView(viewId) {
    const view = document.getElementById(viewId);
    if (view) view.classList.remove('active');
  },

  openModal(modalId) {
    const modal = document.getElementById(modalId);
    if (modal) modal.classList.add('active');
  },

  closeModal(modalId) {
    const modal = document.getElementById(modalId);
    if (modal) modal.classList.remove('active');
  },

  showToast(message, type = 'info') {
    const container = document.getElementById('toast-container');
    if (!container) return;

    const toast = document.createElement('div');
    toast.className = `toast-msg ${type}`;
    
    let icon = 'ℹ️';
    if (type === 'success') icon = '✅';
    else if (type === 'error') icon = '⚠️';
    
    toast.innerHTML = `<span>${icon}</span><span>${message}</span>`;
    container.appendChild(toast);

    if (window.AndroidNative && window.AndroidNative.showToast) {
      window.AndroidNative.showToast(message);
    }

    setTimeout(() => {
      toast.style.opacity = '0';
      toast.style.transform = 'translateY(-10px)';
      toast.style.transition = 'all 0.3s ease';
      setTimeout(() => toast.remove(), 300);
    }, 2800);
  },

  updateResetTimer() {
    const timerEl = document.getElementById('daily-reset-countdown');
    if (timerEl) {
      timerEl.textContent = `Credits reset in ${CreditsManager.getTimeUntilMidnight()}`;
    }
  },

  setupEventListeners() {
    document.querySelectorAll('.nav-item').forEach(item => {
      item.addEventListener('click', () => {
        const nav = item.dataset.nav;
        if (nav === 'home') this.showScreen('home-screen');
        else if (nav === 'create') this.showScreen('create-screen');
        else if (nav === 'projects') this.showScreen('projects-screen');
        else if (nav === 'credits') this.showScreen('credits-screen');
        else if (nav === 'settings') this.showScreen('settings-screen');
      });
    });

    const storyInput = document.getElementById('create-story-input');
    const charCounter = document.getElementById('create-char-count');
    if (storyInput && charCounter) {
      storyInput.addEventListener('input', () => {
        charCounter.textContent = `${storyInput.value.length} characters`;
      });
    }

    document.querySelectorAll('.format-card').forEach(card => {
      card.addEventListener('click', () => {
        document.querySelectorAll('.format-card').forEach(c => c.classList.remove('selected'));
        card.classList.add('selected');
        this.selectedFormat = card.dataset.format;
      });
    });

    document.querySelectorAll('.duration-pill').forEach(pill => {
      pill.addEventListener('click', () => {
        document.querySelectorAll('.duration-pill').forEach(p => p.classList.remove('selected'));
        pill.classList.add('selected');
        this.selectedDuration = pill.dataset.duration;
      });
    });

    document.querySelectorAll('.prompt-chip').forEach(chip => {
      chip.addEventListener('click', () => {
        if (storyInput) {
          storyInput.value = chip.dataset.prompt;
          storyInput.dispatchEvent(new Event('input'));
          this.showToast('Template story loaded!', 'info');
        }
      });
    });

    const btnBreakdown = document.getElementById('btn-auto-breakdown');
    if (btnBreakdown) {
      btnBreakdown.addEventListener('click', () => {
        const story = storyInput ? storyInput.value.trim() : '';
        if (!story) {
          this.showToast('Please enter a story first', 'error');
          return;
        }

        if (!CreditsManager.canAffordBreakdown()) {
          this.showToast('Not enough credits. You need 100 credits.', 'error');
          return;
        }

        this.openModal('modal-confirm-breakdown');
      });
    }

    const btnConfirmBreakdown = document.getElementById('btn-confirm-breakdown-continue');
    if (btnConfirmBreakdown) {
      btnConfirmBreakdown.addEventListener('click', () => {
        this.closeModal('modal-confirm-breakdown');
        
        const deduction = CreditsManager.deductForBreakdown();
        if (!deduction.success) {
          this.showToast(deduction.message, 'error');
          return;
        }

        const story = storyInput ? storyInput.value.trim() : '';
        this.showToast('Analyzing Story with AI...', 'info');

        ScenesManager.breakdownStory(story, this.selectedDuration);
        this.showScreen('scene-breakdown-screen');
      });
    }

    const btnGenerateVideo = document.getElementById('btn-generate-video');
    if (btnGenerateVideo) {
      btnGenerateVideo.addEventListener('click', () => {
        if (!CreditsManager.canAffordVideo()) {
          this.showToast('Not enough credits. You need 400 credits.', 'error');
          return;
        }

        document.getElementById('confirm-video-duration').textContent = this.selectedDuration;
        document.getElementById('confirm-video-format').textContent = this.selectedFormat;
        document.getElementById('confirm-video-quality').textContent = this.selectedQuality;
        document.getElementById('confirm-video-cost').textContent = '400 Credits';

        this.openModal('modal-confirm-video');
      });
    }

    const btnConfirmVideo = document.getElementById('btn-confirm-video-continue');
    if (btnConfirmVideo) {
      btnConfirmVideo.addEventListener('click', () => {
        this.closeModal('modal-confirm-video');

        const story = storyInput ? storyInput.value.trim() : 'काला बिल्ली और सुपरबाइक';
        GeneratorEngine.startGeneration({
          story: story,
          format: this.selectedFormat,
          duration: this.selectedDuration,
          quality: this.selectedQuality
        });
      });
    }

    const charForm = document.getElementById('char-form');
    if (charForm) {
      charForm.addEventListener('submit', (e) => {
        e.preventDefault();
        const id = document.getElementById('char-id').value;
        const name = document.getElementById('char-name').value.trim();
        const age = document.getElementById('char-age').value.trim();
        const appearance = document.getElementById('char-appearance').value.trim();
        const clothes = document.getElementById('char-clothes').value.trim();
        const hairFur = document.getElementById('char-hair').value.trim();
        const accessories = document.getElementById('char-accessories').value.trim();
        const personality = document.getElementById('char-personality').value.trim();
        const avatar = document.getElementById('char-avatar').value.trim() || '👤';

        if (!name) {
          this.showToast('Character name is required', 'error');
          return;
        }

        CharactersManager.save({
          id: id || undefined,
          name, age, appearance, clothes, hairFur, accessories, personality, avatar
        });

        this.closeModal('modal-character');
        this.showToast('Character saved to Bible! 👤', 'success');
      });
    }

    document.querySelectorAll('.modal-close-btn, .btn-modal-cancel').forEach(btn => {
      btn.addEventListener('click', () => {
        document.querySelectorAll('.modal-overlay').forEach(m => m.classList.remove('active'));
      });
    });

    document.querySelectorAll('.modal-overlay').forEach(modal => {
      modal.addEventListener('click', (e) => {
        if (e.target === modal) {
          modal.classList.remove('active');
        }
      });
    });
  }
};

window.handleAndroidBack = function() {
  const openModal = document.querySelector('.modal-overlay.active');
  if (openModal) {
    openModal.classList.remove('active');
    return true;
  }

  const genScreen = document.getElementById('generation-screen');
  if (genScreen && genScreen.classList.contains('active')) {
    GeneratorEngine.simulateFailure();
    return true;
  }

  if (App.activeScreenId === 'scene-breakdown-screen' || App.activeScreenId === 'preview-screen') {
    App.showScreen('create-screen');
    return true;
  } else if (App.activeScreenId !== 'home-screen') {
    App.showScreen('home-screen');
    return true;
  }

  return false;
};

document.addEventListener('DOMContentLoaded', () => {
  App.init();
});

window.App = App;
