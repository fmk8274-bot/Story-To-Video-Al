/**
 * Characters Module - Story To Video AI
 */

const CharactersManager = {
  getAll() {
    return StorageManager.getCharacters();
  },

  getById(id) {
    const all = this.getAll();
    return all.find(c => c.id === id) || null;
  },

  save(characterData) {
    const list = this.getAll();
    if (characterData.id) {
      const idx = list.findIndex(c => c.id === characterData.id);
      if (idx !== -1) {
        list[idx] = { ...list[idx], ...characterData };
      } else {
        list.push(characterData);
      }
    } else {
      characterData.id = 'char_' + Date.now();
      list.push(characterData);
    }
    StorageManager.saveCharacters(list);
    this.renderUI();
    return characterData;
  },

  delete(id) {
    let list = this.getAll();
    list = list.filter(c => c.id !== id);
    StorageManager.saveCharacters(list);
    this.renderUI();
  },

  getConsistencySnippet(charNameOrId) {
    if (!charNameOrId) return '';
    const all = this.getAll();
    const char = all.find(c => c.id === charNameOrId || c.name === charNameOrId);
    if (!char) return '';
    return `[Character Consistency: ${char.name}, Age: ${char.age}, Appearance: ${char.appearance}, Outfit: ${char.clothes}, Hair/Fur: ${char.hairFur}, Accessories: ${char.accessories}]`;
  },

  renderUI() {
    const listContainer = document.getElementById('characters-list-container');
    if (!listContainer) return;

    const characters = this.getAll();
    if (!characters || characters.length === 0) {
      listContainer.innerHTML = `
        <div class="empty-state-box">
          <div class="empty-state-icon">👤</div>
          <div>No characters in Bible yet. Add your first character for consistent video generation!</div>
        </div>
      `;
      return;
    }

    listContainer.innerHTML = characters.map(char => {
      return `
        <div class="character-card" data-id="${char.id}">
          <div class="character-avatar-frame" style="background: ${char.color || 'var(--grad-primary)'};">
            ${char.avatar ? char.avatar : '👤'}
          </div>
          <div class="character-details">
            <div class="character-name-row">
              <span class="character-name">${char.name}</span>
              <span class="character-badge">${char.age || 'Main'}</span>
            </div>
            <div class="character-attr-text"><strong>Appearance:</strong> ${char.appearance || 'Standard'}</div>
            <div class="character-attr-text"><strong>Clothes:</strong> ${char.clothes || 'None'}</div>
            <div class="character-attr-text"><strong>Accessories:</strong> ${char.accessories || 'None'}</div>
            <div class="character-attr-text"><strong>Personality:</strong> ${char.personality || 'Neutral'}</div>
            <div style="display: flex; gap: 8px; margin-top: 8px;">
              <button class="btn-action-small open" onclick="CharactersManager.openEditModal('${char.id}')">✏️ Edit</button>
              <button class="btn-action-small delete" onclick="CharactersManager.confirmDelete('${char.id}')">🗑️ Delete</button>
            </div>
          </div>
        </div>
      `;
    }).join('');

    this.populateDropdown();
  },

  populateDropdown(selectedVal = '') {
    const select = document.getElementById('edit-scene-character');
    if (!select) return;

    const characters = this.getAll();
    let options = '<option value="">None / Environment Only</option>';
    characters.forEach(c => {
      const isSel = c.name === selectedVal || c.id === selectedVal ? 'selected' : '';
      options += `<option value="${c.name}" ${isSel}>${c.name}</option>`;
    });
    select.innerHTML = options;
  },

  openAddModal() {
    document.getElementById('char-modal-title').textContent = 'Add Character to Bible';
    document.getElementById('char-id').value = '';
    document.getElementById('char-name').value = '';
    document.getElementById('char-age').value = '';
    document.getElementById('char-appearance').value = '';
    document.getElementById('char-clothes').value = '';
    document.getElementById('char-hair').value = '';
    document.getElementById('char-accessories').value = '';
    document.getElementById('char-personality').value = '';
    document.getElementById('char-avatar').value = '🐱';
    App.openModal('modal-character');
  },

  openEditModal(id) {
    const char = this.getById(id);
    if (!char) return;

    document.getElementById('char-modal-title').textContent = 'Edit Character';
    document.getElementById('char-id').value = char.id;
    document.getElementById('char-name').value = char.name || '';
    document.getElementById('char-age').value = char.age || '';
    document.getElementById('char-appearance').value = char.appearance || '';
    document.getElementById('char-clothes').value = char.clothes || '';
    document.getElementById('char-hair').value = char.hairFur || '';
    document.getElementById('char-accessories').value = char.accessories || '';
    document.getElementById('char-personality').value = char.personality || '';
    document.getElementById('char-avatar').value = char.avatar || '👤';
    App.openModal('modal-character');
  },

  confirmDelete(id) {
    if (confirm('Are you sure you want to delete this character from the Bible?')) {
      this.delete(id);
      App.showToast('Character deleted from Bible', 'info');
    }
  }
};

window.CharactersManager = CharactersManager;
