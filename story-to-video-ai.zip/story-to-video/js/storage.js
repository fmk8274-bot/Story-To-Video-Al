/**
 * Storage Module - Story To Video AI
 * LocalStorage persistence for user credits, projects, characters, and settings.
 */

const STORAGE_KEYS = {
  CREDITS: 'stv_credits',
  LAST_RESET_DATE: 'stv_last_reset_date',
  PROJECTS: 'stv_projects',
  CHARACTERS: 'stv_characters',
  SETTINGS: 'stv_settings',
  CREDIT_HISTORY: 'stv_credit_history'
};

const DEFAULT_CHARACTERS = [
  {
    id: 'char_billo',
    name: 'बिल्लो (Billo the Biker Cat)',
    age: '2 Years',
    appearance: 'Black glossy sleek cat with glowing emerald green eyes',
    clothes: 'Black leather racer jacket with purple neon stripes',
    hairFur: 'Silky midnight black fur',
    accessories: 'Red racing helmet with dark tinted visor, miniature pilot goggles',
    personality: 'Fearless, fast, mischievous, heroic biker',
    avatar: '🐱',
    color: 'linear-gradient(135deg, #8b5cf6, #ec4899)'
  },
  {
    id: 'char_vikram',
    name: 'कैप्टन विक्रम (Captain Vikram)',
    age: '32 Years',
    appearance: 'Brave astronaut with athletic build and focused brown eyes',
    clothes: 'High-tech white space suit with orange and cyan life-support accents',
    hairFur: 'Short black military cut',
    accessories: 'Gold-plated solar visor helmet, wrist holographic communicator',
    personality: 'Determined, courageous, scientific explorer',
    avatar: '👨‍🚀',
    color: 'linear-gradient(135deg, #06b6d4, #3b82f6)'
  },
  {
    id: 'char_maya',
    name: 'माया (Detective Maya)',
    age: '28 Years',
    appearance: 'Cyberpunk detective with cybernetic blue left eye',
    clothes: 'Dark trench coat with glowing neon collar and tactical combat boots',
    hairFur: 'Neon purple bob haircut with shaved side',
    accessories: 'Data-scanner cyber monocle, neural link earpiece',
    personality: 'Sharp, mysterious, witty, brilliant investigator',
    avatar: '🕵️‍♀️',
    color: 'linear-gradient(135deg, #ec4899, #f43f5e)'
  }
];

const DEFAULT_PROJECTS = [
  {
    id: 'proj_demo_1',
    name: 'काला बिल्ली और सुपरबाइक (Billo The Biker)',
    story: 'एक काला बिल्ली हेलमेट पहनकर बाइक से जा रहा था। रात की चमकती सड़कों पर उसने तेज रफ्तार में स्टंट किया।',
    format: '9:16',
    duration: '1 Min',
    quality: '720p HD',
    date: new Date(Date.now() - 3600000 * 2).toISOString(),
    status: 'Completed',
    scenes: [
      {
        id: 'sc_1',
        title: 'Scene 01',
        duration: 15,
        description: 'काली बिल्ली ने अपना लाल हेलमेट पहना और सुपरबाइक स्टार्ट की।',
        character: 'बिल्लो (Billo the Biker Cat)',
        location: 'Cyberpunk Garage',
        action: 'Starting engine with glowing exhaust',
        cameraAngle: 'Close-up Shot',
        cameraMovement: 'Pan Left to Right',
        lighting: 'Cyberpunk Neon Glow (Pink & Cyan)',
        mood: 'High Energy & Action',
        dialogue: 'सफर शुरू हो चुका है!',
        voiceOver: 'Hindi Dramatic Heroic',
        soundEffects: 'Superbike engine roar, tire screech',
        imageGenerated: true,
        accentColor: '#8b5cf6'
      },
      {
        id: 'sc_2',
        title: 'Scene 02',
        duration: 15,
        description: 'हाईवे पर तेज रफ्तार में बाइक आगे बढ़ती है और लाइटें पीछे छूट जाती हैं।',
        character: 'बिल्लो (Billo the Biker Cat)',
        location: 'Neon Highway',
        action: 'Speeding through midnight traffic',
        cameraAngle: 'Low Angle Action Shot',
        cameraMovement: 'Tracking Follow Shot',
        lighting: 'Moody Dark Noir with Neon Streak',
        mood: 'High Energy & Action',
        dialogue: 'रफ्तार ही मेरी पहचान है!',
        voiceOver: 'Hindi Dramatic Heroic',
        soundEffects: 'Wind whoosh, techno bass drop',
        imageGenerated: true,
        accentColor: '#06b6d4'
      },
      {
        id: 'sc_3',
        title: 'Scene 03',
        duration: 15,
        description: 'पुलिस की गाड़ियां पीछा करती हैं और बिल्ली हवा में छलांग लगाती है।',
        character: 'बिल्लो (Billo the Biker Cat)',
        location: 'Sky Bridge Crossing',
        action: 'Epic jump over barricade in slow motion',
        cameraAngle: 'Wide Cinematic View',
        cameraMovement: 'Fast Zoom In',
        lighting: 'Flashing Police Lights (Blue & Red)',
        mood: 'Suspenseful & Thrilling',
        dialogue: 'अब कोई नहीं रोक सकता!',
        voiceOver: 'Hindi Dramatic Heroic',
        soundEffects: 'Police sirens in distance',
        imageGenerated: true,
        accentColor: '#f43f5e'
      },
      {
        id: 'sc_4',
        title: 'Scene 04',
        duration: 15,
        description: 'शहर की सबसे ऊंची इमारत पर बिल्ली सुरक्षित पहुंचती है और जीत की मुस्कान देती है।',
        character: 'बिल्लो (Billo the Biker Cat)',
        location: 'City Rooftop Helipad',
        action: 'Stopping bike, looking at city skyline',
        cameraAngle: 'Drone Aerial View',
        cameraMovement: '360 Orbit',
        lighting: 'Golden Hour / Moonlight Blend',
        mood: 'Epic & Grand',
        dialogue: 'मिशन पूरा हुआ!',
        voiceOver: 'Hindi Warm Storyteller',
        soundEffects: 'Electronic gadget beep, hydraulic hiss',
        imageGenerated: true,
        accentColor: '#10b981'
      }
    ]
  }
];

const StorageManager = {
  init() {
    this.checkDailyReset();
    if (!this.getCharacters() || this.getCharacters().length === 0) {
      this.saveCharacters(DEFAULT_CHARACTERS);
    }
    if (!this.getProjects() || this.getProjects().length === 0) {
      this.saveProjects(DEFAULT_PROJECTS);
    }
  },

  checkDailyReset() {
    const today = new Date().toDateString();
    const lastReset = localStorage.getItem(STORAGE_KEYS.LAST_RESET_DATE);

    if (lastReset !== today) {
      // It's a new day or first launch -> Reset to 1000 daily free credits
      this.saveCredits(1000);
      localStorage.setItem(STORAGE_KEYS.LAST_RESET_DATE, today);
      this.addCreditTransaction('🎁 Daily Free Reset (1000 Credits)', 1000, 'daily_bonus');
    }
  },

  getCredits() {
    const val = localStorage.getItem(STORAGE_KEYS.CREDITS);
    return val !== null ? parseInt(val, 10) : 1000;
  },

  saveCredits(amount) {
    localStorage.setItem(STORAGE_KEYS.CREDITS, amount.toString());
  },

  getCreditHistory() {
    try {
      const data = localStorage.getItem(STORAGE_KEYS.CREDIT_HISTORY);
      return data ? JSON.parse(data) : [];
    } catch (e) {
      return [];
    }
  },

  addCreditTransaction(title, amount, type = 'usage') {
    const history = this.getCreditHistory();
    const current = this.getCredits();
    let updatedBalance = current;

    if (type === 'usage') {
      updatedBalance = Math.max(0, current - amount);
    } else if (type === 'refund' || type === 'daily_bonus' || type === 'purchase') {
      updatedBalance = current + amount;
    }

    this.saveCredits(updatedBalance);

    history.unshift({
      id: 'tx_' + Date.now(),
      title,
      amount: type === 'usage' ? -amount : amount,
      balance: updatedBalance,
      type,
      timestamp: new Date().toISOString()
    });

    // Keep max 50 logs
    if (history.length > 50) history.pop();

    localStorage.setItem(STORAGE_KEYS.CREDIT_HISTORY, JSON.stringify(history));
    return updatedBalance;
  },

  getCharacters() {
    try {
      const data = localStorage.getItem(STORAGE_KEYS.CHARACTERS);
      return data ? JSON.parse(data) : DEFAULT_CHARACTERS;
    } catch (e) {
      return DEFAULT_CHARACTERS;
    }
  },

  saveCharacters(characters) {
    localStorage.setItem(STORAGE_KEYS.CHARACTERS, JSON.stringify(characters));
  },

  getProjects() {
    try {
      const data = localStorage.getItem(STORAGE_KEYS.PROJECTS);
      return data ? JSON.parse(data) : DEFAULT_PROJECTS;
    } catch (e) {
      return DEFAULT_PROJECTS;
    }
  },

  saveProjects(projects) {
    localStorage.setItem(STORAGE_KEYS.PROJECTS, JSON.stringify(projects));
  },

  getSettings() {
    try {
      const data = localStorage.getItem(STORAGE_KEYS.SETTINGS);
      return data ? JSON.parse(data) : {
        language: 'hi',
        theme: 'dark',
        quality: '720p',
        format: '9:16',
        notifications: true
      };
    } catch (e) {
      return { language: 'hi', theme: 'dark', quality: '720p', format: '9:16', notifications: true };
    }
  },

  saveSettings(settings) {
    localStorage.setItem(STORAGE_KEYS.SETTINGS, JSON.stringify(settings));
  }
};

window.StorageManager = StorageManager;
