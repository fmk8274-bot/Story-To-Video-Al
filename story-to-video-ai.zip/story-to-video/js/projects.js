/**
 * Projects Module - Story To Video AI
 */

const ProjectsManager = {
  currentFilter: 'all',
  activePreviewProject: null,
  playerState: {
    isPlaying: false,
    currentTime: 0,
    totalDuration: 60,
    currentSceneIndex: 0,
    animFrameId: null,
    audioMuted: false
  },

  getAll() {
    return StorageManager.getProjects();
  },

  deleteProject(id) {
    if (!confirm('Are you sure you want to delete this project?')) return;
    let projects = this.getAll();
    projects = projects.filter(p => p.id !== id);
    StorageManager.saveProjects(projects);
    this.renderUI();
    App.showToast('Project deleted', 'info');
  },

  renderUI() {
    const feed = document.getElementById('projects-feed-container');
    if (!feed) return;

    const all = this.getAll();
    let filtered = all;
    if (this.currentFilter === 'completed') {
      filtered = all.filter(p => p.status === 'Completed');
    } else if (this.currentFilter === 'drafts') {
      filtered = all.filter(p => p.status === 'Draft');
    }

    if (!filtered || filtered.length === 0) {
      feed.innerHTML = `
        <div class="empty-state-box">
          <div class="empty-state-icon">📂</div>
          <div>No projects found. Create your first AI Video!</div>
          <button class="btn-primary-large" style="width: auto; margin-top: 10px;" onclick="App.showScreen('create-screen')">
            🎬 Create Video
          </button>
        </div>
      `;
      return;
    }

    feed.innerHTML = filtered.map(proj => {
      const formattedDate = new Date(proj.date).toLocaleDateString([], { month: 'short', day: 'numeric', year: 'numeric' });
      return `
        <div class="project-item-card">
          <div class="project-item-thumb">
            <canvas class="project-thumb-canvas" id="proj-thumb-${proj.id}" width="160" height="160"></canvas>
          </div>
          <div class="project-item-info">
            <div class="project-item-title">${proj.name}</div>
            <div class="project-item-tags">
              <span>⏱️ ${proj.duration}</span> • <span>📐 ${proj.format}</span> • <span>${proj.quality || '720p HD'}</span>
            </div>
            <div class="project-item-tags">📅 ${formattedDate}</div>
            <div class="project-item-status">
              <span>●</span> ${proj.status || 'Completed'}
            </div>
          </div>
          <div class="project-item-actions">
            <button class="btn-action-small open" onclick="ProjectsManager.openProject('${proj.id}')">Open</button>
            <button class="btn-action-small delete" onclick="ProjectsManager.deleteProject('${proj.id}')">Delete</button>
          </div>
        </div>
      `;
    }).join('');

    setTimeout(() => {
      filtered.forEach(proj => {
        const c = document.getElementById(`proj-thumb-${proj.id}`);
        if (c && proj.scenes && proj.scenes[0]) {
          ScenesManager.drawSceneArtwork(c, proj.scenes[0], 0);
        }
      });
    }, 50);

    this.renderHomeStrip();
  },

  renderHomeStrip() {
    const strip = document.getElementById('home-recent-projects-strip');
    if (!strip) return;

    const all = this.getAll();
    if (!all || all.length === 0) {
      strip.innerHTML = `<div style="font-size: 12px; color: var(--text-muted); padding: 10px;">No projects yet. Tap "Create Video" above!</div>`;
      return;
    }

    strip.innerHTML = all.slice(0, 5).map((proj, idx) => {
      return `
        <div class="project-mini-card" onclick="ProjectsManager.openProject('${proj.id}')">
          <div class="project-mini-thumb">
            <canvas id="mini-thumb-${proj.id}" width="160" height="95"></canvas>
            <div class="mini-badge">${proj.format}</div>
          </div>
          <div class="project-mini-info">
            <div class="project-mini-title">${proj.name}</div>
            <div class="project-mini-meta">${proj.duration} • 720p</div>
          </div>
        </div>
      `;
    }).join('');

    setTimeout(() => {
      all.slice(0, 5).forEach(proj => {
        const c = document.getElementById(`mini-thumb-${proj.id}`);
        if (c && proj.scenes && proj.scenes[0]) {
          ScenesManager.drawSceneArtwork(c, proj.scenes[0], 1);
        }
      });
    }, 50);
  },

  setFilter(filterName) {
    this.currentFilter = filterName;
    document.querySelectorAll('.filter-tab').forEach(tab => {
      tab.classList.toggle('active', tab.dataset.filter === filterName);
    });
    this.renderUI();
  },

  openProject(id) {
    const proj = this.getAll().find(p => p.id === id);
    if (!proj) return;

    this.loadProjectIntoPreview(proj);
    App.showScreen('preview-screen');
  },

  loadProjectIntoPreview(project) {
    this.activePreviewProject = project;
    this.pauseVideo();
    this.playerState.currentTime = 0;
    this.playerState.currentSceneIndex = 0;

    const playerBox = document.getElementById('preview-player-container');
    if (playerBox) {
      playerBox.className = `video-player-container ${project.format === '16:9' ? 'format-16-9' : 'format-9-16'}`;
    }

    const badgeFormat = document.getElementById('preview-badge-format');
    if (badgeFormat) badgeFormat.textContent = project.format || '9:16';

    const badgeDuration = document.getElementById('preview-badge-duration');
    if (badgeDuration) badgeDuration.textContent = project.duration || '1 Min';

    const titleEl = document.getElementById('preview-project-title');
    if (titleEl) titleEl.textContent = project.name || 'AI Generated Video';

    let durSec = 60;
    if (project.duration.includes('10 Sec')) durSec = 10;
    else if (project.duration.includes('30 Sec')) durSec = 30;
    else if (project.duration.includes('1 Min')) durSec = 60;
    else if (project.duration.includes('3 Min')) durSec = 180;
    else if (project.duration.includes('5 Min')) durSec = 300;
    this.playerState.totalDuration = durSec;

    this.renderPreviewClipsStrip(project.scenes || []);
    this.renderCurrentPlayerFrame();
  },

  renderPreviewClipsStrip(scenes) {
    const strip = document.getElementById('preview-clips-slider');
    if (!strip) return;

    strip.innerHTML = scenes.map((scene, idx) => {
      return `
        <div class="clip-tab-card ${idx === 0 ? 'active' : ''}" onclick="ProjectsManager.selectSceneClip(${idx})">
          <canvas class="clip-tab-canvas" id="clip-canvas-${idx}" width="85" height="60"></canvas>
          <div class="clip-tab-label">Scene 0${idx + 1}</div>
        </div>
      `;
    }).join('');

    setTimeout(() => {
      scenes.forEach((scene, idx) => {
        const c = document.getElementById(`clip-canvas-${idx}`);
        if (c) ScenesManager.drawSceneArtwork(c, scene, idx);
      });
    }, 50);
  },

  selectSceneClip(idx) {
    if (!this.activePreviewProject || !this.activePreviewProject.scenes) return;
    const scenes = this.activePreviewProject.scenes;
    if (idx >= 0 && idx < scenes.length) {
      this.playerState.currentSceneIndex = idx;
      this.playerState.currentTime = (idx / scenes.length) * this.playerState.totalDuration;
      
      document.querySelectorAll('.clip-tab-card').forEach((el, i) => {
        el.classList.toggle('active', i === idx);
      });

      this.renderCurrentPlayerFrame();
    }
  },

  togglePlayPause() {
    if (this.playerState.isPlaying) {
      this.pauseVideo();
    } else {
      this.playVideo();
    }
  },

  playVideo() {
    if (!this.activePreviewProject) return;
    this.playerState.isPlaying = true;

    const playBtn = document.getElementById('player-play-btn');
    if (playBtn) playBtn.textContent = '⏸️';

    const stepTime = 100;
    this.playerState.animInterval = setInterval(() => {
      if (this.playerState.currentTime < this.playerState.totalDuration) {
        this.playerState.currentTime += 0.2;
        this.updatePlayerProgress();
        this.renderCurrentPlayerFrame();
      } else {
        this.playerState.currentTime = 0;
        this.pauseVideo();
      }
    }, stepTime);
  },

  pauseVideo() {
    this.playerState.isPlaying = false;
    if (this.playerState.animInterval) {
      clearInterval(this.playerState.animInterval);
    }
    const playBtn = document.getElementById('player-play-btn');
    if (playBtn) playBtn.textContent = '▶️';
  },

  updatePlayerProgress() {
    const cur = this.playerState.currentTime;
    const tot = this.playerState.totalDuration;
    const pct = Math.min(100, (cur / tot) * 100);

    const bar = document.getElementById('player-progress-fill');
    if (bar) bar.style.width = pct + '%';

    const curTimeEl = document.getElementById('player-time-current');
    if (curTimeEl) {
      const curM = Math.floor(cur / 60);
      const curS = Math.floor(cur % 60);
      curTimeEl.textContent = `${curM}:${curS.toString().padStart(2, '0')}`;
    }

    const totTimeEl = document.getElementById('player-time-total');
    if (totTimeEl) {
      const totM = Math.floor(tot / 60);
      const totS = Math.floor(tot % 60);
      totTimeEl.textContent = `${totM}:${totS.toString().padStart(2, '0')}`;
    }

    if (this.activePreviewProject && this.activePreviewProject.scenes) {
      const scenes = this.activePreviewProject.scenes;
      const sceneIndex = Math.min(scenes.length - 1, Math.floor((cur / tot) * scenes.length));
      if (sceneIndex !== this.playerState.currentSceneIndex) {
        this.playerState.currentSceneIndex = sceneIndex;
        document.querySelectorAll('.clip-tab-card').forEach((el, i) => {
          el.classList.toggle('active', i === sceneIndex);
        });
      }
    }
  },

  renderCurrentPlayerFrame() {
    const canvas = document.getElementById('preview-player-canvas');
    if (!canvas || !this.activePreviewProject) return;

    const scenes = this.activePreviewProject.scenes || [];
    const currentScene = scenes[this.playerState.currentSceneIndex] || scenes[0];
    if (!currentScene) return;

    const ctx = canvas.getContext('2d');
    const w = canvas.width;
    const h = canvas.height;

    ScenesManager.drawSceneArtwork(canvas, currentScene, this.playerState.currentSceneIndex);

    if (this.playerState.isPlaying) {
      const t = this.playerState.currentTime;
      ctx.save();
      const vigGrad = ctx.createRadialGradient(w/2, h/2, w*0.3, w/2, h/2, w*0.8);
      vigGrad.addColorStop(0, 'rgba(0,0,0,0)');
      vigGrad.addColorStop(1, 'rgba(0,0,0,0.4)');
      ctx.fillStyle = vigGrad;
      ctx.fillRect(0, 0, w, h);

      ctx.fillStyle = 'rgba(255,255,255,0.03)';
      ctx.fillRect(0, (t * 50) % h, w, 4);
      ctx.restore();
    }

    if (currentScene.dialogue) {
      ctx.save();
      ctx.fillStyle = 'rgba(0, 0, 0, 0.75)';
      ctx.fillRect(16, h - 55, w - 32, 38);
      ctx.strokeStyle = 'rgba(139, 92, 246, 0.4)';
      ctx.lineWidth = 1;
      ctx.strokeRect(16, h - 55, w - 32, 38);

      ctx.fillStyle = '#ffffff';
      ctx.font = 'bold 13px sans-serif';
      ctx.textAlign = 'center';
      ctx.fillText(currentScene.dialogue, w / 2, h - 31);
      ctx.restore();
    }
  },

  exportVideo() {
    App.showToast('Exporting 720p MP4 Video...', 'info');
    setTimeout(() => {
      App.showToast('Video saved to Gallery / Downloads folder! 🎥', 'success');
    }, 1200);
  },

  shareVideo() {
    if (window.AndroidNative && window.AndroidNative.shareText) {
      window.AndroidNative.shareText('Story To Video AI', 'Watch my AI generated video created with Story To Video AI!');
    } else if (navigator.share) {
      navigator.share({
        title: 'Story To Video AI',
        text: 'Turn your story into an AI video with Story To Video AI!',
        url: window.location.href
      }).catch(() => {});
    } else {
      App.showToast('Video link copied to clipboard! 📋', 'success');
    }
  }
};

window.ProjectsManager = ProjectsManager;
