/**
 * Generator Module - Story To Video AI
 * Multi-step AI Video Generation Pipeline, Mock API interfaces,
 * Progress HUD controller, and Credit Refund Simulator.
 */

const GeneratorEngine = {
  isGenerating: false,
  generationInterval: null,
  currentProgress: 0,
  shouldSimulateFailure: false,

  /**
   * Modular API Interfaces (Ready for Backend/AI Integration)
   */
  async generateSceneImage(prompt, characterData) {
    // Mock image generation API call
    return new Promise(resolve => setTimeout(() => resolve({ success: true, url: 'mock_frame.png' }), 600));
  },

  async generateVoice(text, voiceModel = 'hi-IN-Standard-A') {
    // Mock TTS API call
    return new Promise(resolve => setTimeout(() => resolve({ success: true, audioUrl: 'mock_voice.mp3' }), 500));
  },

  async generateVideo(scenes, config) {
    // Mock Video Synthesis API call
    return new Promise(resolve => setTimeout(() => resolve({ success: true, videoUrl: 'mock_video_720p.mp4' }), 1200));
  },

  /**
   * Starts the 8-stage Video Generation Workflow
   */
  startGeneration(projectData) {
    if (this.isGenerating) return;

    // Deduct 400 credits
    const deduction = CreditsManager.deductForVideo();
    if (!deduction.success) {
      App.showToast(deduction.message, 'error');
      return;
    }

    this.isGenerating = true;
    this.currentProgress = 0;
    this.shouldSimulateFailure = false;

    // Switch to Fullscreen Generation HUD
    App.showFullscreenView('generation-screen');
    this.resetStepsUI();

    const stages = [
      { pct: 12, text: '🔍 Analyzing Story & Beats...', stepIndex: 0 },
      { pct: 28, text: '🎬 Generating Scene Prompts...', stepIndex: 1 },
      { pct: 45, text: '🖼️ Creating Consistent Keyframes...', stepIndex: 2 },
      { pct: 62, text: '🎞️ Generating AI Motion Video Clips...', stepIndex: 3 },
      { pct: 78, text: '🎙️ Adding Hindi AI Voiceover...', stepIndex: 4 },
      { pct: 88, text: '🎵 Mixing Cinematic Background Score...', stepIndex: 5 },
      { pct: 96, text: '⚡ Rendering 720p HD Final Stream...', stepIndex: 6 },
      { pct: 100, text: '🎉 Video Creation Complete!', stepIndex: 7 }
    ];

    let currentStageIdx = 0;

    this.generationInterval = setInterval(() => {
      // Check if user clicked simulate failure
      if (this.shouldSimulateFailure) {
        this.triggerFailureRefund();
        return;
      }

      if (this.currentProgress < 100) {
        this.currentProgress += 1;
        this.updateProgressUI(this.currentProgress);

        const currentStage = stages[currentStageIdx];
        if (currentStage && this.currentProgress >= currentStage.pct) {
          this.setStepActive(currentStage.stepIndex, currentStage.text);
          currentStageIdx++;
        }
      } else {
        clearInterval(this.generationInterval);
        this.isGenerating = false;
        setTimeout(() => {
          this.onGenerationComplete(projectData);
        }, 600);
      }
    }, 45); // Takes ~4.5 seconds for complete animated showcase
  },

  updateProgressUI(pct) {
    const percentEl = document.getElementById('gen-progress-percent');
    if (percentEl) percentEl.textContent = `${pct}%`;
  },

  resetStepsUI() {
    for (let i = 0; i < 8; i++) {
      const el = document.getElementById(`gen-step-${i}`);
      if (el) {
        el.className = 'gen-step-item';
        const icon = el.querySelector('.gen-step-status-icon');
        if (icon) icon.textContent = '⏳';
      }
    }
  },

  setStepActive(index, statusText) {
    const statusEl = document.getElementById('gen-current-status-text');
    if (statusEl) statusEl.textContent = statusText;

    // Mark prior steps completed
    for (let i = 0; i < index; i++) {
      const prev = document.getElementById(`gen-step-${i}`);
      if (prev) {
        prev.className = 'gen-step-item completed';
        const icon = prev.querySelector('.gen-step-status-icon');
        if (icon) icon.textContent = '✅';
      }
    }

    // Set current active
    const current = document.getElementById(`gen-step-${index}`);
    if (current) {
      current.className = 'gen-step-item active';
      const icon = current.querySelector('.gen-step-status-icon');
      if (icon) icon.textContent = '⚡';
    }
  },

  /**
   * Demo Failure and Refund Simulation Logic
   */
  simulateFailure() {
    if (!this.isGenerating) {
      App.showToast('Please start video generation first to test refund', 'info');
      return;
    }
    this.shouldSimulateFailure = true;
  },

  triggerFailureRefund() {
    clearInterval(this.generationInterval);
    this.isGenerating = false;

    // Refund 400 Credits
    CreditsManager.refundCredits(400, 'Video Render Simulated Failure');

    App.hideFullscreenView('generation-screen');
    App.showScreen('scene-breakdown-screen');

    setTimeout(() => {
      alert('Generation failed. Your credits have been refunded (400 Credits returned).');
      App.showToast('400 Credits Refunded to your wallet', 'success');
    }, 200);
  },

  /**
   * Successful Video Generation Callback
   */
  onGenerationComplete(projectData) {
    const newProject = {
      id: 'proj_' + Date.now(),
      name: projectData.story.substring(0, 30) + '...',
      story: projectData.story,
      format: projectData.format || '9:16',
      duration: projectData.duration || '1 Min',
      quality: '720p HD',
      date: new Date().toISOString(),
      status: 'Completed',
      scenes: ScenesManager.getScenes()
    };

    // Save project into Storage
    const existingProjects = StorageManager.getProjects();
    existingProjects.unshift(newProject);
    StorageManager.saveProjects(existingProjects);

    // Load project into Preview Screen
    ProjectsManager.loadProjectIntoPreview(newProject);

    App.hideFullscreenView('generation-screen');
    App.showScreen('preview-screen');
    App.showToast('Your AI Video is Ready! 🎉', 'success');
  }
};

window.GeneratorEngine = GeneratorEngine;
