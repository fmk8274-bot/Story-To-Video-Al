/**
 * Storage Module - Story To Video AI
 * LocalStorage wrapper with default seeds, project persistence, and daily credit reset.
 */

const STORAGE_KEYS = {
  CREDITS: 'stv_credits',
  CREDIT_HISTORY: 'stv_credit_history',
  LAST_RESET_DATE: 'stv_last_reset_date',
  PROJECTS: 'stv_projects',
  CHARACTERS: 'stv_characters',
  CURRENT_DRAFT: 'stv_current_draft',
  SETTINGS: 'stv_settings'
};

const DEFAULT_CHARACTERS = [
  {
    id: 'char_cat_01',
    name: 'बिल्लो (Billo the Biker Cat)',
    age: '3 Years',
    appearance: 'काली चमकदार बिल्ली, हरी चमकती आँखें, स्पोर्टी लुक',
    clothes: 'रेसिंग लेदर जैकेट, छोटे बूट्स',
    hairFur: 'सिल्की ब्लैक फर',
    accessories: 'मिनी नियॉन रेड हेलमेट, गॉगल्स',
    personality: 'साहसी, तेज-तर्रार, निडर और सुपर कूल',
    avatar: '🐱🏍️',
    color: '#8b5cf6'
  },
  {
    id: 'char_hero_02',
    name: 'कबीर (Cyber Detective)',
    age: '28 Years',
    appearance: 'लम्बा, गंभीर चेहरा, साइबरपंक स्टाइल',
    clothes: 'हाई-टेक डार्क ट्रेंच कोट',
    hairFur: 'शॉर्ट स्पाइकी ब्लैक हेयर',
    accessories: 'होलोग्राफिक आई-ग्लास, स्मार्ट वॉच',
    personality: 'रहस्यमयी, बुद्धिमान, न्यायप्रिय',
    avatar: '🕵️‍♂️⚡',
    color: '#06b6d4'
  }
];

const DEFAULT_PROJECTS = [
  {
    id: 'proj_demo_cat',
    name: 'काला बिल्ली और सुपरबाइक',
    story: 'एक काला बिल्ली हेलमेट पहनकर बाइक से जा रहा था। रात की चमकती सड़कों पर उसने पुलिस की गाड़ी को चकमा दिया और अपने गुप्त अड्डे पर पहुँचा।',
    format: '9:16',
    duration: '1 Min',
    quality: '720p HD',
    date: new Date(Date.now() - 3600000 * 5).toISOString(),
    status: 'Completed',
    scenes: [
      {
        id: 'scene_1',
        title: 'Scene 01: सड़कों पर रफ्तार',
        duration: 15,
        description: 'एक काला बिल्ली लाल हेलमेट पहनकर नियॉन लाइट वाली सड़क पर सुपरबाइक दौड़ा रहा है।',
        character: 'बिल्लो (Billo the Biker Cat)',
        location: 'Cyberpunk Neon Highway',
        action: 'Speeding on motorcycle, tilting on curves',
        cameraAngle: 'Low Angle Tracking Shot',
        cameraMovement: 'Fast Pan Forward',
        lighting: 'Cyberpunk Neon Glow (Pink & Blue)',
        mood: 'High Energy & Action',
        dialogue: 'आज कोई मुझे पकड़ नहीं सकता!',
        voiceOver: 'Hindi Dramatic Heroic',
        soundEffects: 'Superbike engine roar, tire screech',
        imageGenerated: true,
        accentColor: '#8b5cf6'
      },
      {
        id: 'scene_2',
        title: 'Scene 02: पुलिस का सायरन',
        duration: 15,
        description: 'पीछे से पुलिस की सायरन बजती है और बिल्ली गॉगल्स ठीक करके स्पीड बढ़ाता है।',
        character: 'बिल्लो (Billo the Biker Cat)',
        location: 'Downtown Traffic',
        action: 'Looking back into rearview mirror',
        cameraAngle: 'Close-up on Cat Face',
        cameraMovement: 'Slow Zoom In',
        lighting: 'Flashing Red & Blue Police Lights',
        mood: 'Suspenseful & Thrilling',
        dialogue: 'सायरन बज चुका है, अब गियर बदलना होगा।',
        voiceOver: 'Hindi Confident Male',
        soundEffects: 'Police siren, turbo boost whine',
        imageGenerated: true,
        accentColor: '#06b6d4'
      },
      {
        id: 'scene_3',
        title: 'Scene 03: जादुई छलांग',
        duration: 15,
        description: 'पुल के किनारे से बाइक हवा में छलांग लगाती है और दूसरी छत पर सुरक्षित लैंड होती है।',
        character: 'बिल्लो (Billo the Biker Cat)',
        location: 'Sky Bridge Rooftop',
        action: 'Flying mid-air jump against full moon',
        cameraAngle: 'Wide Cinematic Slow-Mo',
        cameraMovement: 'Orbit Shot',
        lighting: 'Moonlight Silhouette',
        mood: 'Epic & Grand',
        dialogue: 'मिशन सफल!',
        voiceOver: 'Hindi Heroic Voice',
        soundEffects: 'Whoosh wind, heavy landing thump',
        imageGenerated: true,
        accentColor: '#ec4899'
      },
      {
        id: 'scene_4',
        title: 'Scene 04: गुप्त ठिकाना',
        duration: 15,
        description: 'बिल्ली अपने सीक्रेट बंकर में उतरकर हेलमेट उतारती है और मुस्कुराती है।',
        character: 'बिल्लो (Billo the Biker Cat)',
        location: 'Secret Cyber Bunker',
        action: 'Removing helmet and winking',
        cameraAngle: 'Medium Shot',
        cameraMovement: 'Static',
        lighting: 'Warm Studio Glow',
        mood: 'Cool & Satisfied',
        dialogue: 'अगला मिशन कल शुरू होगा।',
        voiceOver: 'Hindi Narration Outro',
        soundEffects: 'Door hydraulic hiss, electronic chime',
        imageGenerated: true,
        accentColor: '#10b981'
      }
    ]
  }
];

const DEFAULT_SETTINGS = {
  language: 'hi',
  theme: 'dark',
  videoQuality: '720p',
  defaultFormat: '9:16',
  notifications: true
};

const StorageManager = {
  init() {
    this.checkDailyCreditReset();
    if (!localStorage.getItem(STORAGE_KEYS.CHARACTERS)) {
      this.saveCharacters(DEFAULT_CHARACTERS);
    }
    if (!localStorage.getItem(STORAGE_KEYS.PROJECTS)) {
      this.saveProjects(DEFAULT_PROJECTS);
    }
    if (!localStorage.getItem(STORAGE_KEYS.SETTINGS)) {
      this.saveSettings(DEFAULT_SETTINGS);
    }
    if (!localStorage.getItem(STORAGE_KEYS.CURRENT_DRAFT)) {
      this.saveCurrentDraft({
        story: 'एक काला बिल्ली हेलमेट पहनकर बाइक से जा रहा था। रास्ते में उसने कई रोमांचक स्टंट किए।',
        format: '9:16',
        duration: '1 Min',
        quality: '720p HD',
        scenes: []
      });
    }
  },

  checkDailyCreditReset() {
    const todayStr = new Date().toISOString().split('T')[0];
    const lastReset = localStorage.getItem(STORAGE_KEYS.LAST_RESET_DATE);

    if (!lastReset || lastReset !== todayStr) {
      // New day! Reset to 1000 daily credits
      localStorage.setItem(STORAGE_KEYS.CREDITS, '1000');
      localStorage.setItem(STORAGE_KEYS.LAST_RESET_DATE, todayStr);
      
      const history = this.getCreditHistory();
      history.unshift({
        id: 'hist_' + Date.now(),
        type: 'daily_bonus',
        title: 'Daily Free Credits Claimed',
        amount: 1000,
        balance: 1000,
        timestamp: new Date().toISOString()
      });
      this.saveCreditHistory(history);
      return true;
    }
    return false;
  },

  getCredits() {
    const creds = localStorage.getItem(STORAGE_KEYS.CREDITS);
    return creds !== null ? parseInt(creds, 10) : 1000;
  },

  saveCredits(amount) {
    const validAmount = Math.max(0, parseInt(amount, 10) || 0);
    localStorage.setItem(STORAGE_KEYS.CREDITS, validAmount.toString());
    return validAmount;
  },

  getCreditHistory() {
    const hist = localStorage.getItem(STORAGE_KEYS.CREDIT_HISTORY);
    if (!hist) {
      return [
        {
          id: 'hist_init',
          type: 'daily_bonus',
          title: 'Daily Free Credits',
          amount: 1000,
          balance: 1000,
          timestamp: new Date().toISOString()
        }
      ];
    }
    try {
      return JSON.parse(hist);
    } catch(e) {
      return [];
    }
  },

  saveCreditHistory(history) {
    localStorage.setItem(STORAGE_KEYS.CREDIT_HISTORY, JSON.stringify(history));
  },

  addCreditTransaction(title, amount, type = 'usage') {
    const current = this.getCredits();
    const newBalance = type === 'refund' || type === 'daily_bonus' || type === 'purchase'
      ? current + Math.abs(amount)
      : Math.max(0, current - Math.abs(amount));

    this.saveCredits(newBalance);

    const history = this.getCreditHistory();
    history.unshift({
      id: 'tx_' + Date.now() + '_' + Math.random().toString(36).substring(2, 6),
      type: type,
      title: title,
      amount: type === 'usage' ? -Math.abs(amount) : Math.abs(amount),
      balance: newBalance,
      timestamp: new Date().toISOString()
    });
    this.saveCreditHistory(history.slice(0, 30)); // keep last 30 transactions
    return newBalance;
  },

  getProjects() {
    try {
      const data = localStorage.getItem(STORAGE_KEYS.PROJECTS);
      return data ? JSON.parse(data) : DEFAULT_PROJECTS;
    } catch(e) {
      return DEFAULT_PROJECTS;
    }
  },

  saveProjects(projects) {
    localStorage.setItem(STORAGE_KEYS.PROJECTS, JSON.stringify(projects));
  },

  getCharacters() {
    try {
      const data = localStorage.getItem(STORAGE_KEYS.CHARACTERS);
      return data ? JSON.parse(data) : DEFAULT_CHARACTERS;
    } catch(e) {
      return DEFAULT_CHARACTERS;
    }
  },

  saveCharacters(chars) {
    localStorage.setItem(STORAGE_KEYS.CHARACTERS, JSON.stringify(chars));
  },

  getCurrentDraft() {
    try {
      const data = localStorage.getItem(STORAGE_KEYS.CURRENT_DRAFT);
      return data ? JSON.parse(data) : null;
    } catch(e) {
      return null;
    }
  },

  saveCurrentDraft(draft) {
    localStorage.setItem(STORAGE_KEYS.CURRENT_DRAFT, JSON.stringify(draft));
  },

  getSettings() {
    try {
      const data = localStorage.getItem(STORAGE_KEYS.SETTINGS);
      return data ? JSON.parse(data) : DEFAULT_SETTINGS;
    } catch(e) {
      return DEFAULT_SETTINGS;
    }
  },

  saveSettings(settings) {
    localStorage.setItem(STORAGE_KEYS.SETTINGS, JSON.stringify(settings));
  }
};

window.StorageManager = StorageManager;
