/**
 * Scenes Module - Story To Video AI
 * Auto Scene Breakdown algorithm, Scene Editor CRUD, and Procedural Scene Artwork Engine.
 */

const ScenesManager = {
  currentScenes: [],
  editingSceneIndex: -1,

  getScenes() {
    return this.currentScenes;
  },

  setScenes(scenes) {
    this.currentScenes = scenes || [];
    this.renderUI();
  },

  /**
   * AI-powered Story Decomposition Logic
   * Splits user story (Hindi / English) into coherent cinematic scenes
   */
  breakdownStory(storyText, durationStr = '1 Min', characterName = '') {
    if (!storyText || storyText.trim().length === 0) {
      storyText = 'एक काला बिल्ली हेलमेट पहनकर बाइक से जा रहा था।';
    }

    // Determine target scene count based on duration
    let targetCount = 4;
    let sceneDuration = 15;
    if (durationStr.includes('10 Sec')) {
      targetCount = 2;
      sceneDuration = 5;
    } else if (durationStr.includes('30 Sec')) {
      targetCount = 3;
      sceneDuration = 10;
    } else if (durationStr.includes('1 Min')) {
      targetCount = 4;
      sceneDuration = 15;
    } else if (durationStr.includes('3 Min')) {
      targetCount = 6;
      sceneDuration = 30;
    } else if (durationStr.includes('5 Min')) {
      targetCount = 8;
      sceneDuration = 38;
    }

    // Match characters or default to Billo
    const defaultChar = characterName || 'बिल्लो (Billo the Biker Cat)';

    // Intelligent breakdown based on story sentences or keywords
    const sentences = storyText.split(/[।.\n!?]+/).filter(s => s.trim().length > 3);
    const scenes = [];

    const cameraAngles = ['Close-up Shot', 'Wide Cinematic View', 'Low Angle Action Shot', 'Drone Aerial View', 'Dutch Tilt Angle', 'Eye Level Portrait'];
    const cameraMovements = ['Pan Left to Right', 'Fast Zoom In', 'Tracking Follow Shot', '360 Orbit', 'Slow Motion Push', 'Static Cinematic'];
    const lightings = ['Cyberpunk Neon Glow (Pink & Cyan)', 'Moody Dark Noir', 'Golden Hour Sunlight', 'Flashing Police Lights', 'Dramatic Moonlight', 'Studio Warm Softbox'];
    const moods = ['High Energy & Action', 'Suspenseful & Thrilling', 'Epic & Grand', 'Mysterious & Sci-Fi', 'Humorous & Cool', 'Emotional'];
    const soundEffects = ['Superbike engine roar, tire screech', 'Police sirens in distance', 'Wind whoosh, techno bass drop', 'Thunder, rain on asphalt', 'Electronic gadget beep, hydraulic hiss'];
    const voices = ['Hindi Dramatic Heroic', 'Hindi Confident Male', 'Hindi Warm Storyteller', 'English AI Cinematic'];
    const accentColors = ['#8b5cf6', '#06b6d4', '#ec4899', '#f59e0b', '#10b981', '#3b82f6', '#f43f5e'];

    for (let i = 0; i < targetCount; i++) {
      const sentenceText = sentences[i % sentences.length] || `दृश्य ${i + 1}: कहानी का अगला रोमांचक मोड़।`;
      
      scenes.push({
        id: 'scene_' + Date.now() + '_' + i,
        title: `Scene 0${i + 1}`,
        duration: sceneDuration,
        description: sentenceText.trim(),
        character: defaultChar,
        location: i === 0 ? 'Cyber Highway Entrance' : i === 1 ? 'Downtown Neon Crossing' : i === 2 ? 'Sky Bridge Rooftop' : 'Secret Underground Bunker',
        action: i === 0 ? 'Accelerating motorbike into the night' : i === 1 ? 'Evading obstacles with sharp turns' : i === 2 ? 'Mid-air leap over police barricade' : 'Arriving at destination, celebrating victory',
        cameraAngle: cameraAngles[i % cameraAngles.length],
        cameraMovement: cameraMovements[i % cameraMovements.length],
        lighting: lightings[i % lightings.length],
        mood: moods[i % moods.length],
        dialogue: i === 0 ? 'सफर शुरू हो चुका है!' : i === 1 ? 'रफ्तार ही मेरी पहचान है!' : i === 2 ? 'अब कोई नहीं रोक सकता!' : 'मिशन पूरा हुआ!',
        voiceOver: voices[i % voices.length],
        soundEffects: soundEffects[i % soundEffects.length],
        imageGenerated: false,
        accentColor: accentColors[i % accentColors.length]
      });
    }

    this.currentScenes = scenes;
    this.renderUI();
    return scenes;
  },

  renderUI() {
    const listContainer = document.getElementById('scene-cards-container');
    const countBadge = document.getElementById('scene-count-badge');
    
    if (countBadge) {
      countBadge.textContent = `${this.currentScenes.length} Scenes`;
    }

    if (!listContainer) return;

    if (this.currentScenes.length === 0) {
      listContainer.innerHTML = `
        <div class="empty-state-box">
          <div class="empty-state-icon">🎬</div>
          <div>No scenes generated yet. Click "Auto Scene Breakdown" to analyze your story!</div>
        </div>
      `;
      return;
    }

    listContainer.innerHTML = this.currentScenes.map((scene, idx) => {
      return `
        <div class="scene-card" data-index="${idx}" style="border-left: 4px solid ${scene.accentColor || '#8b5cf6'};">
          <div class="scene-card-header">
            <div class="scene-number-badge">
              <span>🎬 Scene 0${idx + 1}</span>
            </div>
            <div class="scene-duration-badge">⏱️ ${scene.duration}s</div>
          </div>

          <div class="scene-description-text">
            ${scene.description}
          </div>

          <div class="scene-image-preview-box" id="scene-preview-box-${idx}">
            <canvas class="scene-canvas-preview" id="scene-canvas-${idx}" width="360" height="200"></canvas>
          </div>

          <div class="scene-tags-row">
            <span class="scene-tag">👤 ${scene.character || 'No Char'}</span>
            <span class="scene-tag">🎥 ${scene.cameraAngle}</span>
            <span class="scene-tag">💡 ${scene.lighting}</span>
            <span class="scene-tag">🔊 ${scene.voiceOver}</span>
          </div>

          <div class="scene-actions-grid">
            <button class="btn-scene-action" onclick="ScenesManager.openEditor(${idx})">
              <span>✏️</span> Edit
            </button>
            <button class="btn-scene-action" onclick="ScenesManager.triggerGenerateImage(${idx})">
              <span>🖼️</span> Gen Image
            </button>
            <button class="btn-scene-action" onclick="ScenesManager.regenerateScene(${idx})">
              <span>🔄</span> Regenerate
            </button>
            <button class="btn-scene-action danger" onclick="ScenesManager.deleteScene(${idx})">
              <span>🗑️</span> Delete
            </button>
          </div>
        </div>
      `;
    }).join('');

    // Render artwork on each canvas
    setTimeout(() => {
      this.currentScenes.forEach((scene, idx) => {
        const canvas = document.getElementById(`scene-canvas-${idx}`);
        if (canvas) {
          this.drawSceneArtwork(canvas, scene, idx);
        }
      });
    }, 50);
  },

  /**
   * Procedural Cinematic Canvas Art Generator
   * Creates vibrant cyberpunk / cinematic artwork directly on HTML5 Canvas
   */
  drawSceneArtwork(canvas, scene, seed = 0) {
    const ctx = canvas.getContext('2d');
    const w = canvas.width;
    const h = canvas.height;

    // Background Gradient
    const bgGrad = ctx.createLinearGradient(0, 0, w, h);
    if (seed % 4 === 0) {
      bgGrad.addColorStop(0, '#1e1035');
      bgGrad.addColorStop(0.5, '#0d1326');
      bgGrad.addColorStop(1, '#05070c');
    } else if (seed % 4 === 1) {
      bgGrad.addColorStop(0, '#2d0f2a');
      bgGrad.addColorStop(0.5, '#12122b');
      bgGrad.addColorStop(1, '#05070c');
    } else if (seed % 4 === 2) {
      bgGrad.addColorStop(0, '#092532');
      bgGrad.addColorStop(0.5, '#0e1526');
      bgGrad.addColorStop(1, '#05070c');
    } else {
      bgGrad.addColorStop(0, '#2a1a08');
      bgGrad.addColorStop(0.5, '#181224');
      bgGrad.addColorStop(1, '#05070c');
    }
    ctx.fillStyle = bgGrad;
    ctx.fillRect(0, 0, w, h);

    // Distant Neon City Skyline
    ctx.fillStyle = '#0f172a';
    for (let x = 10; x < w; x += 32) {
      const bH = 40 + Math.sin(x * 0.1 + seed) * 35 + ((x * 17) % 40);
      ctx.fillRect(x, h - 80 - bH, 26, bH + 80);
      
      // Building windows
      ctx.fillStyle = (x + seed) % 3 === 0 ? 'rgba(6, 182, 212, 0.4)' : 'rgba(236, 72, 153, 0.3)';
      for (let wy = h - 70 - bH; wy < h - 90; wy += 14) {
        ctx.fillRect(x + 5, wy, 4, 6);
        ctx.fillRect(x + 15, wy, 4, 6);
      }
      ctx.fillStyle = '#0f172a';
    }

    // Glowing Neon Grid Highway
    const roadY = h - 70;
    const roadGrad = ctx.createLinearGradient(0, roadY, 0, h);
    roadGrad.addColorStop(0, '#131127');
    roadGrad.addColorStop(1, '#22143b');
    ctx.fillStyle = roadGrad;
    ctx.beginPath();
    ctx.moveTo(0, roadY);
    ctx.lineTo(w, roadY);
    ctx.lineTo(w, h);
    ctx.lineTo(0, h);
    ctx.closePath();
    ctx.fill();

    // Perspective Highway Neon Lines
    ctx.strokeStyle = scene.accentColor || '#8b5cf6';
    ctx.lineWidth = 2;
    ctx.shadowBlur = 12;
    ctx.shadowColor = scene.accentColor || '#8b5cf6';

    const vanishingX = w / 2;
    const vanishingY = roadY;
    for (let l = -2; l <= 2; l++) {
      ctx.beginPath();
      ctx.moveTo(vanishingX + l * 20, vanishingY);
      ctx.lineTo(vanishingX + l * 90, h);
      ctx.stroke();
    }
    ctx.shadowBlur = 0;

    // Glowing Moon / Neon Sun in sky
    const sunX = seed % 2 === 0 ? w * 0.75 : w * 0.25;
    const sunY = 45;
    const sunGrad = ctx.createRadialGradient(sunX, sunY, 5, sunX, sunY, 35);
    sunGrad.addColorStop(0, '#ffffff');
    sunGrad.addColorStop(0.3, scene.accentColor || '#ec4899');
    sunGrad.addColorStop(1, 'transparent');
    ctx.fillStyle = sunGrad;
    ctx.beginPath();
    ctx.arc(sunX, sunY, 35, 0, Math.PI * 2);
    ctx.fill();

    // Central Hero Silhouette: Cool Biker Cat or Cyber Vehicle
    ctx.save();
    ctx.translate(w / 2, roadY + 25);
    
    // Bike Glow
    ctx.shadowBlur = 18;
    ctx.shadowColor = scene.accentColor || '#06b6d4';
    ctx.fillStyle = '#000000';
    
    // Bike Body
    ctx.beginPath();
    ctx.ellipse(0, 0, 36, 12, 0, 0, Math.PI * 2);
    ctx.fill();

    // Bike Wheels
    ctx.fillStyle = '#1e293b';
    ctx.strokeStyle = '#38bdf8';
    ctx.lineWidth = 3;
    ctx.beginPath();
    ctx.arc(-26, 8, 12, 0, Math.PI * 2);
    ctx.arc(26, 8, 12, 0, Math.PI * 2);
    ctx.stroke();
    ctx.fill();

    // Cat Rider Silhouette with Helmet
    ctx.fillStyle = '#090a0f';
    ctx.beginPath();
    ctx.arc(0, -18, 11, 0, Math.PI * 2); // Head/Helmet
    ctx.fill();

    // Helmet Visor Neon Glow
    ctx.fillStyle = '#f43f5e';
    ctx.shadowColor = '#f43f5e';
    ctx.shadowBlur = 10;
    ctx.fillRect(2, -20, 8, 4);

    // Cat Ears
    ctx.fillStyle = '#090a0f';
    ctx.beginPath();
    ctx.moveTo(-6, -26);
    ctx.lineTo(-2, -33);
    ctx.lineTo(2, -26);
    ctx.fill();

    // Headlight Beam
    ctx.restore();
    ctx.save();
    const beamGrad = ctx.createLinearGradient(w / 2 + 25, roadY + 25, w, roadY + 35);
    beamGrad.addColorStop(0, 'rgba(6, 182, 212, 0.7)');
    beamGrad.addColorStop(1, 'rgba(6, 182, 212, 0)');
    ctx.fillStyle = beamGrad;
    ctx.beginPath();
    ctx.moveTo(w / 2 + 30, roadY + 25);
    ctx.lineTo(w, roadY + 5);
    ctx.lineTo(w, roadY + 55);
    ctx.closePath();
    ctx.fill();
    ctx.restore();

    // Watermark tag
    ctx.fillStyle = 'rgba(255,255,255,0.7)';
    ctx.font = 'bold 11px sans-serif';
    ctx.fillText(`Scene 0${seed + 1} • 720p HD AI Frame`, 12, 24);
  },

  openEditor(idx) {
    this.editingSceneIndex = idx;
    const scene = this.currentScenes[idx];
    if (!scene) return;

    document.getElementById('edit-scene-desc').value = scene.description || '';
    document.getElementById('edit-scene-location').value = scene.location || '';
    document.getElementById('edit-scene-action').value = scene.action || '';
    document.getElementById('edit-scene-angle').value = scene.cameraAngle || 'Close-up Shot';
    document.getElementById('edit-scene-movement').value = scene.cameraMovement || 'Pan Left to Right';
    document.getElementById('edit-scene-lighting').value = scene.lighting || 'Cyberpunk Neon Glow (Pink & Cyan)';
    document.getElementById('edit-scene-mood').value = scene.mood || 'High Energy & Action';
    document.getElementById('edit-scene-dialogue').value = scene.dialogue || '';
    document.getElementById('edit-scene-voice').value = scene.voiceOver || 'Hindi Dramatic Heroic';
    document.getElementById('edit-scene-sfx').value = scene.soundEffects || '';
    document.getElementById('edit-scene-duration').value = scene.duration || 15;

    CharactersManager.populateDropdown(scene.character);
    App.openModal('modal-scene-editor');
  },

  saveEditedScene() {
    if (this.editingSceneIndex === -1) return;
    const scene = this.currentScenes[this.editingSceneIndex];
    if (!scene) return;

    scene.description = document.getElementById('edit-scene-desc').value;
    scene.character = document.getElementById('edit-scene-character').value;
    scene.location = document.getElementById('edit-scene-location').value;
    scene.action = document.getElementById('edit-scene-action').value;
    scene.cameraAngle = document.getElementById('edit-scene-angle').value;
    scene.cameraMovement = document.getElementById('edit-scene-movement').value;
    scene.lighting = document.getElementById('edit-scene-lighting').value;
    scene.mood = document.getElementById('edit-scene-mood').value;
    scene.dialogue = document.getElementById('edit-scene-dialogue').value;
    scene.voiceOver = document.getElementById('edit-scene-voice').value;
    scene.soundEffects = document.getElementById('edit-scene-sfx').value;
    scene.duration = parseInt(document.getElementById('edit-scene-duration').value, 10) || 15;

    App.closeModal('modal-scene-editor');
    this.renderUI();
    App.showToast('Scene updated successfully!', 'success');
  },

  addNewScene() {
    const idx = this.currentScenes.length;
    this.currentScenes.push({
      id: 'scene_' + Date.now(),
      title: `Scene 0${idx + 1}`,
      duration: 15,
      description: 'नया दृश्य: रोमांचक घटना और अगला ऐक्शन सीन।',
      character: 'बिल्लो (Billo the Biker Cat)',
      location: 'City Streets',
      action: 'Racing ahead towards the goal',
      cameraAngle: 'Wide Cinematic View',
      cameraMovement: 'Tracking Follow Shot',
      lighting: 'Cyberpunk Neon Glow',
      mood: 'High Energy & Action',
      dialogue: 'मंजिल अब करीब है!',
      voiceOver: 'Hindi Dramatic Heroic',
      soundEffects: 'Superbike engine roar',
      imageGenerated: false,
      accentColor: '#8b5cf6'
    });
    this.renderUI();
    App.showToast('New scene added to breakdown', 'info');
  },

  deleteScene(idx) {
    if (this.currentScenes.length <= 1) {
      App.showToast('Video must have at least 1 scene', 'error');
      return;
    }
    this.currentScenes.splice(idx, 1);
    this.renderUI();
    App.showToast('Scene deleted', 'info');
  },

  regenerateScene(idx) {
    const scene = this.currentScenes[idx];
    if (!scene) return;
    scene.accentColor = '#' + Math.floor(Math.random()*16777215).toString(16);
    this.renderUI();
    App.showToast(`Scene 0${idx + 1} regenerated with new style!`, 'success');
  },

  triggerGenerateImage(idx) {
    const scene = this.currentScenes[idx];
    if (!scene) return;

    this.editingSceneIndex = idx;
    const modalCanvas = document.getElementById('image-gen-modal-canvas');
    if (modalCanvas) {
      this.drawSceneArtwork(modalCanvas, scene, idx + Date.now());
    }

    const consistency = CharactersManager.getConsistencySnippet(scene.character);
    const promptBox = document.getElementById('image-gen-prompt-text');
    if (promptBox) {
      promptBox.value = `Cinematic 720p HD frame of ${scene.description}. Action: ${scene.action}. Camera: ${scene.cameraAngle}, ${scene.cameraMovement}. Lighting: ${scene.lighting}. Mood: ${scene.mood}. ${consistency}`;
    }

    App.openModal('modal-image-gen');
  },

  confirmUseGeneratedImage() {
    if (this.editingSceneIndex !== -1) {
      const scene = this.currentScenes[this.editingSceneIndex];
      if (scene) {
        scene.imageGenerated = true;
        this.renderUI();
      }
    }
    App.closeModal('modal-image-gen');
    App.showToast('AI Scene Image applied!', 'success');
  }
};

window.ScenesManager = ScenesManager;
