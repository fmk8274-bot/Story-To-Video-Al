/**
 * Credits Module - Story To Video AI
 * Strict Credit Management:
 * - Initial/Daily: 1000 Credits
 * - Auto Scene Breakdown: 100 Credits
 * - Complete Video: 400 Credits (Fixed for all durations & formats)
 * - Insufficient balance protection
 * - Automatic refund handler
 */

const CREDIT_COSTS = {
  SCENE_BREAKDOWN: 100,
  COMPLETE_VIDEO: 400,
  DAILY_FREE: 1000
};

const CreditsManager = {
  getCredits() {
    return StorageManager.getCredits();
  },

  canAffordBreakdown() {
    return this.getCredits() >= CREDIT_COSTS.SCENE_BREAKDOWN;
  },

  canAffordVideo() {
    return this.getCredits() >= CREDIT_COSTS.COMPLETE_VIDEO;
  },

  deductForBreakdown() {
    if (!this.canAffordBreakdown()) {
      return { success: false, message: 'Not enough credits. You need 100 credits.' };
    }
    const newBal = StorageManager.addCreditTransaction('🎬 Auto Scene Breakdown', CREDIT_COSTS.SCENE_BREAKDOWN, 'usage');
    this.updateUI();
    return { success: true, balance: newBal };
  },

  deductForVideo() {
    if (!this.canAffordVideo()) {
      return { success: false, message: 'Not enough credits. You need 400 credits.' };
    }
    const newBal = StorageManager.addCreditTransaction('🎥 Complete Video Generation', CREDIT_COSTS.COMPLETE_VIDEO, 'usage');
    this.updateUI();
    return { success: true, balance: newBal };
  },

  refundCredits(amount = 400, reason = 'Generation failed') {
    const newBal = StorageManager.addCreditTransaction(`🔄 Refund: ${reason}`, amount, 'refund');
    this.updateUI();
    return newBal;
  },

  resetDailyCredits() {
    StorageManager.saveCredits(CREDIT_COSTS.DAILY_FREE);
    StorageManager.addCreditTransaction('🎁 Daily Free Reset (1000 Credits)', CREDIT_COSTS.DAILY_FREE, 'daily_bonus');
    this.updateUI();
    return CREDIT_COSTS.DAILY_FREE;
  },

  buyCredits(amount) {
    const newBal = StorageManager.addCreditTransaction(`💳 Purchased Credits Pack (+${amount})`, amount, 'purchase');
    this.updateUI();
    return newBal;
  },

  updateUI() {
    const credits = this.getCredits();
    
    // Header & Badges
    const badgeElements = document.querySelectorAll('.dynamic-credits-val');
    badgeElements.forEach(el => {
      el.textContent = credits.toLocaleString();
    });

    // Home screen daily quota bar
    const quotaProgress = document.getElementById('daily-quota-progress');
    if (quotaProgress) {
      const pct = Math.min(100, (credits / CREDIT_COSTS.DAILY_FREE) * 100);
      quotaProgress.style.width = pct + '%';
    }

    // Breakdown Button status
    const breakdownBtn = document.getElementById('btn-auto-breakdown');
    if (breakdownBtn) {
      if (!this.canAffordBreakdown()) {
        breakdownBtn.classList.add('disabled-credits');
      } else {
        breakdownBtn.classList.remove('disabled-credits');
      }
    }

    // Video Generate Button status
    const videoBtn = document.getElementById('btn-generate-video');
    if (videoBtn) {
      if (!this.canAffordVideo()) {
        videoBtn.classList.add('disabled-credits');
      } else {
        videoBtn.classList.remove('disabled-credits');
      }
    }

    // Render credit usage history if visible
    this.renderHistoryList();
  },

  renderHistoryList() {
    const container = document.getElementById('credit-history-feed');
    if (!container) return;

    const history = StorageManager.getCreditHistory();
    if (!history || history.length === 0) {
      container.innerHTML = `<div class="empty-state-box"><div class="empty-state-icon">💳</div><div>No transaction history yet</div></div>`;
      return;
    }

    container.innerHTML = history.map(item => {
      const isPositive = item.amount > 0;
      const formattedDate = new Date(item.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', month: 'short', day: 'numeric' });
      const sign = isPositive ? '+' : '';
      const icon = item.type === 'refund' ? '🔄' : item.type === 'daily_bonus' ? '🎁' : item.type === 'purchase' ? '💳' : '🎬';

      return `
        <div class="history-item">
          <div class="history-item-left">
            <div class="history-icon-box">${icon}</div>
            <div>
              <div class="history-title">${item.title}</div>
              <div class="history-date">${formattedDate} • Balance: ${item.balance}</div>
            </div>
          </div>
          <div class="history-amount ${isPositive ? 'positive' : 'negative'}">
            ${sign}${item.amount}
          </div>
        </div>
      `;
    }).join('');
  },

  getTimeUntilMidnight() {
    const now = new Date();
    const midnight = new Date(now);
    midnight.setHours(24, 0, 0, 0);
    const diffMs = midnight - now;
    const hours = Math.floor(diffMs / (1000 * 60 * 60));
    const mins = Math.floor((diffMs % (1000 * 60 * 60)) / (1000 * 60));
    return `${hours.toString().padStart(2, '0')}h ${mins.toString().padStart(2, '0')}m`;
  }
};

window.CreditsManager = CreditsManager;
window.CREDIT_COSTS = CREDIT_COSTS;
