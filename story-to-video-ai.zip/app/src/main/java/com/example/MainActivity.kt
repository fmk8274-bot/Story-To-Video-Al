package com.example

import android.annotation.SuppressLint
import android.content.Intent
import android.graphics.Bitmap
import android.net.Uri
import android.os.Bundle
import android.view.ViewGroup
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.OnBackPressedCallback
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.viewinterop.AndroidView

class MainActivity : ComponentActivity() {

  private var webView: WebView? = null

  @SuppressLint("SetJavaScriptEnabled")
  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    enableEdgeToEdge()

    val backCallback = object : OnBackPressedCallback(true) {
      override fun handleOnBackPressed() {
        webView?.let { wv ->
          if (wv.canGoBack()) {
            wv.goBack()
          } else {
            // Dispatch back event to JS app
            wv.evaluateJavascript("if (window.handleAndroidBack) { window.handleAndroidBack(); } else { false; }") { result ->
              if (result == "false" || result == null) {
                isEnabled = false
                onBackPressedDispatcher.onBackPressed()
                isEnabled = true
              }
            }
          }
        } ?: run {
          isEnabled = false
          onBackPressedDispatcher.onBackPressed()
          isEnabled = true
        }
      }
    }
    onBackPressedDispatcher.addCallback(this, backCallback)

    setContent {
      Box(
        modifier = Modifier
          .fillMaxSize()
          .background(Color(0xFF090A0F))
          .statusBarsPadding()
          .navigationBarsPadding()
      ) {
        AndroidWebViewContainer(
          onWebViewCreated = { wv ->
            webView = wv
          }
        )
      }
    }
  }

  @SuppressLint("SetJavaScriptEnabled")
  @Composable
  fun AndroidWebViewContainer(onWebViewCreated: (WebView) -> Unit) {
    AndroidView(
      modifier = Modifier.fillMaxSize(),
      factory = { context ->
        WebView(context).apply {
          layoutParams = ViewGroup.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.MATCH_PARENT
          )
          setBackgroundColor(android.graphics.Color.parseColor("#090A0F"))

          settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            databaseEnabled = true
            allowFileAccess = true
            allowContentAccess = true
            loadsImagesAutomatically = true
            loadWithOverviewMode = true
            useWideViewPort = true
            mixedContentMode = WebSettings.MIXED_CONTENT_ALWAYS_ALLOW
            cacheMode = WebSettings.LOAD_DEFAULT
            mediaPlaybackRequiresUserGesture = false
            builtInZoomControls = false
            displayZoomControls = false
            setSupportZoom(false)
          }

          addJavascriptInterface(WebAppInterface(this@MainActivity), "AndroidNative")

          webChromeClient = WebChromeClient()
          webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(
              view: WebView?,
              request: WebResourceRequest?
            ): Boolean {
              val url = request?.url?.toString() ?: return false
              if (url.startsWith("http://") || url.startsWith("https://")) {
                val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url))
                context.startActivity(intent)
                return true
              }
              return false
            }
          }

          loadUrl("file:///android_asset/story-to-video/index.html")
          onWebViewCreated(this)
        }
      }
    )
  }

  inner class WebAppInterface(private val activity: ComponentActivity) {
    @JavascriptInterface
    fun showToast(message: String) {
      activity.runOnUiThread {
        Toast.makeText(activity, message, Toast.LENGTH_SHORT).show()
      }
    }

    @JavascriptInterface
    fun shareText(title: String, text: String) {
      activity.runOnUiThread {
        val sendIntent = Intent().apply {
          action = Intent.ACTION_SEND
          putExtra(Intent.EXTRA_TITLE, title)
          putExtra(Intent.EXTRA_TEXT, text)
          type = "text/plain"
        }
        val shareIntent = Intent.createChooser(sendIntent, title)
        activity.startActivity(shareIntent)
      }
    }
  }

  override fun onDestroy() {
    webView?.destroy()
    webView = null
    super.onDestroy()
  }
}
